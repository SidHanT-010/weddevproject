<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Map</title>
<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
<style>
    #map {
        height: 800px;
    }
</style>
</head>
<body>

<h1>Map</h1>

<div id="map"></div>

<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script>

var map = L.map('map').setView([0, 0], 13);


L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);


<?php

function getIPAddress($ipAddress) {
    $ipAddress = trim($ipAddress); 

    if (filter_var($ipAddress,
                    FILTER_VALIDATE_IP,
                    FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)
        !== false) {
        return $ipAddress;
    }

    return null;
}


$userIPAddress = "152.58.31.23";
$ip = getIPAddress($userIPAddress);


    $locationData = file_get_contents(filename:"http://ip-api.com/json/$ip");
    $loc = json_decode ($locationData);
    $lat = $loc->lat;
    $lon = $loc->lon;

$otherPersonsLatitude = "15.4588"; 
$otherPersonsLongitude = "73.8342"; 
?>

function showOtherPersonsLocation(latitude, longitude) {
    
    map.setView([latitude, longitude], 13);
    L.marker([latitude, longitude]).addTo(map)
        .bindPopup('Other Person\'s Location').openPopup();
}


showOtherPersonsLocation(<?php echo $otherPersonsLatitude; ?>, <?php echo $otherPersonsLongitude; ?>);
</script>

</body>
</html>
